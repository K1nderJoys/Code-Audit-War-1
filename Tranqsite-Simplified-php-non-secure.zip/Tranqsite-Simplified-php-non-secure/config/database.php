<?php
    $config = [
        'server' => '127.0.0.1',
        'username' => 'root',
        'password' => '',
        'database' => 'tranqsite_la07',
    ];
